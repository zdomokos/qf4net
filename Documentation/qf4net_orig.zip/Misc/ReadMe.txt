Visio Stencils:
To incorporate the stencil into Visio, unzip the archive Visio.ZIP and copy the stencil file Software - UML.vss into your Visio/Stencils directory. Similarly you can copy the template file Software - UML.vst to Visio/Template directory.

Note: the stencils are copied from Miro Samek's Web Site http://www.quantum-leaps.com.